import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import axios from 'axios'
Vue.use(VueRouter)
let routes = [
  {
    path: '/',
    component: App
  }
]
let router = new VueRouter(routes)
router.beforeEach((to,form,next) => {
  let index = window.location.href.indexOf('?')
  if (index) {
    let str = window.location.href.substr(index + 1)
    let uias_sso_sessionid = ''
    let arr = str.split('&')
    arr.forEach((item) => {
      let mid = item.split('=')
      if (mid[0] === 'uias_sso_sessionid') {
        uias_sso_sessionid = mid[1]
      }
    })
    if (uias_sso_sessionid) {
      window.sessionStorage.setItem('uias_sso_sessionid',uias_sso_sessionid)
    }
  }
  let token = window.sessionStorage.getItem('uias_sso_sessionid')
  axios.defaults.headers.uias_sso_sessionid = token
  axios.get('http://10.12.102.241:8085/api/').then((data) => {
    if (String(data.data.code) === '200') {
      next(to)
      return
    }
    location.href = data.data.loginPageUrl
  })
})
Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
