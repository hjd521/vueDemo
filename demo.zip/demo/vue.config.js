/**
 * Created by 侯建东 on 2019/4/22.
 */
const path = require('path')
const ZipPlugin = require('zip-webpack-plugin')
module.exports = {
  chainWebpack: config => {
    config.module
        .rule('images')
        .use('url-loader')
        .loader('url-loader')
        .tap(options => Object.assign(options, {limit: 10240}))
  },
  configureWebpack: {
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
        '@co': path.resolve(__dirname, './src/components'),
      },
      extensions: ['.js', '.vue', '.json']
    },
    module: {
      rules: [
        {
          test: '/\.js$/',
          use: ['babel-loader?cacheDirectory'],
          include: path.resolve(__dirname, 'src'),
          exclude: path.resolve(__dirname, 'node_modules')
        }
      ]
    },
    plugins: [
      new ZipPlugin({
        path: path.resolve('../platform/'),
        filename: 'dist.zip'
      })
    ]
  },
  css: {
    loaderOptions: {
      less: {
        modifyVars: {
          'primary-color': '#3EBA8D',
          'link-color': '#3EBA8D',
          'border-radius-base': '1px',
          'btn-primary-bg': '#3EBA8D',
          'heading-color': '#3EBA8D'
        },
        javascriptEnabled: true
      }
    }
  },
  devServer: {
    https: false,
    proxy: {
        '/api': {
            target: 'http://10.12.102.241:8085',
            changeOrigin: true,
            onProxyReq: function(proxyReq) {
              proxyReq.removeHeader('origin')
            }
        }
    }
}
}